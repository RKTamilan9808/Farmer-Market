# Farmers' Market Orders & Payments (Java Console Application)

**Course:** 23CSR306 Java Programming - Assignment II, Farmers' Market Orders & Payments
**Student Name:** POOVARASAN S
**Roll No.:** 717825I145
**Branch / Section:** AD / A
**Repository link:** https://github.com/poovarasan-1711/farmers-market-orders

## Problem Statement
Develop a console app to manage products, customers, orders, payments, and late fees, with
stock-availability tracking and no over-ordering of products.

## Features
- Menu: Add Product / Register Customer / Place Order / Make Payment /
  Display Products & Stock / Exit.
- Regular customers: 3 open orders, 2 days to pay. Loyalty customers: 5 open orders, 7 days
  to pay, 5% discount (not on Organic products) and half the late fee.
- Dairy products carry a 5% packing charge; Seasonal products are listed but never ordered.
- Late fee: 2% of the order total per day late, never above 20% of the order total.
- Payment modes: Cash, UPI (no fee) and Card (1.5% processing fee).
- All input is validated with custom exceptions.

## Project Structure
```
src/ model/ service/ util/ exception/ main/
```

## How to Compile and Run
```bash
mkdir out
javac -d out $(find src -name "*.java")
java -cp out main.MarketApp
```
In Eclipse: create a Java project, copy the src packages in and run
MarketApp.java as a Java Application. Dates use dd-MM-yyyy.
