package util;

import exception.InvalidInputException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Pattern;

/** Reads and validates console input. Every error is reported as an InvalidInputException. */
public class InputHelper {
    private static final Pattern PHONE = Pattern.compile("^[6-9][0-9]{9}$");
    private static final Pattern NAME = Pattern.compile("^[A-Za-z][A-Za-z .'-]{1,49}$");
    private static final Pattern UPI = Pattern.compile("^[A-Za-z0-9._-]{2,}@[A-Za-z]{2,}$");
    private static final Pattern CARD4 = Pattern.compile("^[0-9]{4}$");
    private static final Pattern LINE = Pattern.compile("^P[0-9]{3,4}:[0-9]{1,4}$");

    private final Scanner scanner;

    public InputHelper(Scanner scanner) { this.scanner = scanner; }

    private String prompt(String message) {
        System.out.print(message);
        return scanner.nextLine().trim();
    }

    public String readText(String message) throws InvalidInputException {
        String s = prompt(message);
        if (s.isEmpty()) {
            throw new InvalidInputException("Input cannot be empty.");
        }
        if (s.length() > 60) {
            throw new InvalidInputException("Input is too long (maximum 60 characters).");
        }
        return s;
    }

    public String readName(String message) throws InvalidInputException {
        String s = readText(message);
        if (!NAME.matcher(s).matches()) {
            throw new InvalidInputException(
                    "Name must start with a letter and contain only letters, spaces, . ' or -.");
        }
        return s;
    }

    /** Reads a 10-digit Indian mobile number (starts with 6-9). */
    public String readPhone(String message) throws InvalidInputException {
        String s = readText(message);
        if (!PHONE.matcher(s).matches()) {
            throw new InvalidInputException("'" + s + "' is not a valid 10-digit mobile number.");
        }
        return s;
    }

    public String readUpiId(String message) throws InvalidInputException {
        String s = readText(message);
        if (!UPI.matcher(s).matches()) {
            throw new InvalidInputException("'" + s + "' is not a valid UPI ID (example: name@bank).");
        }
        return s;
    }

    public String readCardLast4(String message) throws InvalidInputException {
        String s = readText(message);
        if (!CARD4.matcher(s).matches()) {
            throw new InvalidInputException("Enter exactly the last 4 digits of the card.");
        }
        return s;
    }

    public int readInt(String message, int min, int max) throws InvalidInputException {
        String s = prompt(message);
        try {
            int v = Integer.parseInt(s);
            if (v < min || v > max) {
                throw new InvalidInputException("Value must be between " + min + " and " + max + ".");
            }
            return v;
        } catch (NumberFormatException e) {
            throw new InvalidInputException("'" + s + "' is not a valid whole number.");
        }
    }

    public double readPrice(String message, double min, double max) throws InvalidInputException {
        String s = prompt(message);
        try {
            double v = Double.parseDouble(s);
            if (Double.isNaN(v) || v < min || v > max) {
                throw new InvalidInputException("Amount must be between " + min + " and " + max + ".");
            }
            return v;
        } catch (NumberFormatException e) {
            throw new InvalidInputException("'" + s + "' is not a valid amount.");
        }
    }

    /** Reads a dd-MM-yyyy date; when allowToday is true an empty line returns today's date. */
    public LocalDate readDate(String message, boolean allowToday) throws InvalidInputException {
        String s = prompt(message);
        if (s.isEmpty() && allowToday) {
            return LocalDate.now();
        }
        try {
            return LocalDate.parse(s, DateUtil.FMT);
        } catch (DateTimeParseException e) {
            throw new InvalidInputException("'" + s + "' is not a valid date (use dd-MM-yyyy).");
        }
    }

    /**
     * Reads order lines such as "P001:3, P002:2" (product ID : quantity) and rejects
     * malformed entries, zero quantities and repeated products.
     */
    public Map<String, Integer> readOrderLines(String message) throws InvalidInputException {
        String s = readText(message).toUpperCase();
        Map<String, Integer> lines = new LinkedHashMap<>();
        for (String token : s.split("[,\\s]+")) {
            if (token.isEmpty()) {
                continue;
            }
            if (!LINE.matcher(token).matches()) {
                throw new InvalidInputException("'" + token
                        + "' is not valid; use PRODUCTID:QUANTITY (example: P001:3).");
            }
            String id = token.substring(0, token.indexOf(':'));
            int qty = Integer.parseInt(token.substring(token.indexOf(':') + 1));
            if (qty < 1) {
                throw new InvalidInputException("Quantity for " + id + " must be at least 1.");
            }
            if (lines.containsKey(id)) {
                throw new InvalidInputException("Product " + id + " was entered more than once.");
            }
            lines.put(id, qty);
        }
        return lines;
    }
}
