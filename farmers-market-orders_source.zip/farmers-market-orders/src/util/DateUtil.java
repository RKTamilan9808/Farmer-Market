package util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;

/** Common date format (dd-MM-yyyy), money formatting and text fitting used across the application. */
public final class DateUtil {
    public static final DateTimeFormatter FMT =
            DateTimeFormatter.ofPattern("dd-MM-uuuu").withResolverStyle(ResolverStyle.STRICT);

    private DateUtil() { }

    public static String format(LocalDate date) { return date.format(FMT); }

    public static String money(double amount) { return String.format("Rs.%.2f", amount); }

    /** Rounds an amount to two decimal places (paise). */
    public static double round2(double amount) { return Math.round(amount * 100.0) / 100.0; }

    /** Cuts a long text to the given width so that table columns stay aligned. */
    public static String fit(String text, int width) {
        if (text.length() <= width) {
            return text;
        }
        return text.substring(0, width - 2) + "..";
    }
}
