package service;

/**
 * Late-payment policy (business rule 4).
 * Late fee = days late x 2% of the order total, capped at 20% of the order total.
 * A customer's own factor (e.g. Loyalty = 0.5) is applied on top by the Payment class.
 */
public final class LateFeePolicy {
    public static final double RATE_PER_DAY = 0.02;
    public static final double MAX_RATE = 0.20;

    private LateFeePolicy() { }

    public static double grossLateFee(long daysLate, double orderTotal) {
        if (daysLate <= 0) {
            return 0.0;
        }
        return Math.round(Math.min(daysLate * RATE_PER_DAY, MAX_RATE) * orderTotal * 100.0) / 100.0;
    }

    /** True when the 20% ceiling is what limits the late fee. */
    public static boolean isCapped(long daysLate) { return daysLate * RATE_PER_DAY > MAX_RATE; }
}
