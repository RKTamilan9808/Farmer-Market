package service;

import exception.CustomerBlockedException;
import exception.InvalidInputException;
import exception.ItemNotFoundException;
import exception.OrderLimitExceededException;
import exception.OutOfStockException;
import exception.PaymentNotAllowedException;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;
import model.CardPayment;
import model.CashPayment;
import model.Customer;
import model.DairyProduct;
import model.Farmer;
import model.LoyaltyCustomer;
import model.Order;
import model.OrderItem;
import model.OrganicProduct;
import model.Payment;
import model.Product;
import model.SeasonalProduct;
import model.UpiPayment;
import util.DateUtil;

/**
 * Core service class. It aggregates farmers, products, customers and orders and
 * enforces every business rule of the Farmers' Market Orders & Payments system.
 */
public class MarketService {
    private final String name;
    private final Map<String, Farmer> farmers = new LinkedHashMap<>();     // key = lower-case name|village
    private final Map<String, Product> products = new LinkedHashMap<>();
    private final Map<String, Customer> customers = new LinkedHashMap<>();
    private final Map<String, Order> orders = new LinkedHashMap<>();
    private final Map<String, String> phones = new LinkedHashMap<>();      // phone -> customer ID
    private int farmerSeq = 1;
    private int productSeq = 1;
    private int customerSeq = 1;
    private int orderSeq = 1;
    private int paymentSeq = 1;

    public MarketService(String name) { this.name = name; }

    public String getName() { return name; }

    // ------------------------------------------------------------------ add
    /** type: 1 = Produce, 2 = Dairy, 3 = Organic, 4 = Seasonal (out of season). */
    public Product addProduct(String productName, String farmerName, String village, String description,
            int type, int quantity, double price) throws InvalidInputException {
        if (type < 1 || type > 4) {
            throw new InvalidInputException("Product type must be 1 (Produce), 2 (Dairy), 3 (Organic) or 4 (Seasonal).");
        }
        if (quantity < 1 || quantity > 500) {
            throw new InvalidInputException("A product needs 1-500 units in stock.");
        }
        if (price <= 0) {
            throw new InvalidInputException("Price must be greater than zero.");
        }
        for (Product p : products.values()) {
            if (p.getName().equalsIgnoreCase(productName)
                    && p.getFarmer().getName().equalsIgnoreCase(farmerName)) {
                throw new InvalidInputException("'" + productName + "' by " + farmerName
                        + " is already in the catalogue (" + p.getProductId() + ").");
            }
        }
        String key = farmerName.toLowerCase() + "|" + village.toLowerCase();
        Farmer farmer = farmers.get(key);
        if (farmer == null) {
            farmer = new Farmer(String.format("F%03d", farmerSeq++), farmerName, village);
            farmers.put(key, farmer);
        }
        String id = String.format("P%03d", productSeq++);
        Product product;
        if (type == 2) {
            product = new DairyProduct(id, productName, farmer, description, price, quantity);
        } else if (type == 3) {
            product = new OrganicProduct(id, productName, farmer, description, price, quantity);
        } else if (type == 4) {
            product = new SeasonalProduct(id, productName, farmer, description, price, quantity);
        } else {
            product = new Product(id, productName, farmer, description, price, quantity);
        }
        products.put(id, product);
        return product;
    }

    public Customer registerCustomer(String customerName, String phone, boolean loyalty)
            throws InvalidInputException {
        if (phones.containsKey(phone)) {
            throw new InvalidInputException("The mobile number " + phone + " is already registered to customer "
                    + phones.get(phone) + ".");
        }
        String id = String.format("C%03d", customerSeq++);
        Customer c = loyalty ? new LoyaltyCustomer(id, customerName, phone) : new Customer(id, customerName, phone);
        customers.put(id, c);
        phones.put(phone, id);
        return c;
    }

    // --------------------------------------------------------------- lookup
    public Product findProduct(String id) throws ItemNotFoundException {
        Product p = products.get(id.toUpperCase());
        if (p == null) {
            throw new ItemNotFoundException("No product found with ID '" + id + "'.");
        }
        return p;
    }

    public Customer findCustomer(String id) throws ItemNotFoundException {
        Customer c = customers.get(id.toUpperCase());
        if (c == null) {
            throw new ItemNotFoundException("No customer found with ID '" + id + "'.");
        }
        return c;
    }

    public Order findOrder(String id) throws ItemNotFoundException {
        Order o = orders.get(id.toUpperCase());
        if (o == null) {
            throw new ItemNotFoundException("No order found with ID '" + id + "'.");
        }
        return o;
    }

    // ---------------------------------------------------------------- order
    /** Places an order for the given product IDs and quantities and reserves the stock. */
    public Order placeOrder(String customerId, Map<String, Integer> lines, LocalDate date)
            throws ItemNotFoundException, OutOfStockException, OrderLimitExceededException,
            CustomerBlockedException, InvalidInputException {
        Customer customer = findCustomer(customerId);
        if (lines.isEmpty()) {
            throw new InvalidInputException("Select at least one product.");
        }
        if (customer.hasOverdue(date)) {
            throw new CustomerBlockedException(customer.getName()
                    + " has overdue unpaid orders; pay them before ordering more.");
        }
        if (customer.getOpenCount() + 1 > customer.getMaxOpenOrders()) {
            throw new OrderLimitExceededException(customer.getName() + " (" + customer.getCustomerType()
                    + ") can have at most " + customer.getMaxOpenOrders() + " unpaid orders at a time ("
                    + customer.getOpenCount() + " already open).");
        }
        // Validate every line first, so a failed request never reserves stock for half of the order.
        Map<Product, Integer> chosen = new LinkedHashMap<>();
        for (Map.Entry<String, Integer> e : lines.entrySet()) {
            Product product = findProduct(e.getKey());
            int qty = e.getValue();
            if (!product.isOrderable()) {
                throw new OutOfStockException("'" + product.getName() + "' is out of season (display only).");
            }
            if (qty > product.getMaxQtyPerOrder()) {
                throw new InvalidInputException("At most " + product.getMaxQtyPerOrder() + " " + product.getUnit()
                        + " of '" + product.getName() + "' can be ordered at a time.");
            }
            if (qty > product.getAvailableQty()) {
                throw new OutOfStockException("Only " + product.getAvailableQty() + " " + product.getUnit()
                        + " of '" + product.getName() + "' (" + product.getProductId() + ") available; "
                        + qty + " requested.");
            }
            if (customer.holds(product)) {
                throw new InvalidInputException(customer.getName() + " already has an unpaid order for '"
                        + product.getName() + "'; pay for it first.");
            }
            chosen.put(product, qty);
        }
        for (Map.Entry<Product, Integer> e : chosen.entrySet()) {
            e.getKey().reserve(e.getValue());   // second line of defence against over-ordering
        }
        String id = String.format("ON%03d", orderSeq++);
        Order order = new Order(id, customer, chosen, date);
        customer.addOpen(order);
        orders.put(id, order);
        return order;
    }

    // -------------------------------------------------------------- payment
    /** mode: 1 = Cash, 2 = UPI, 3 = Card. The reference is the UPI ID or the last 4 card digits. */
    public Payment makePayment(String orderId, int mode, String reference, LocalDate date)
            throws ItemNotFoundException, PaymentNotAllowedException, InvalidInputException {
        Order order = findOrder(orderId);
        if (order.isPaid()) {
            throw new PaymentNotAllowedException("Order " + order.getOrderId() + " is already paid.");
        }
        if (date.isBefore(order.getOrderDate())) {
            throw new InvalidInputException("Payment date cannot be before the order date ("
                    + DateUtil.format(order.getOrderDate()) + ").");
        }
        if (mode < 1 || mode > 3) {
            throw new InvalidInputException("Payment mode must be 1 (Cash), 2 (UPI) or 3 (Card).");
        }
        if (mode != 1 && (reference == null || reference.isEmpty())) {
            throw new InvalidInputException("A UPI ID or card number is required for this payment mode.");
        }
        long late = order.daysLate(date);
        double policyFee = LateFeePolicy.grossLateFee(late, order.getTotal());
        boolean capped = LateFeePolicy.isCapped(late);
        String id = String.format("PY%03d", paymentSeq++);
        Payment payment;
        if (mode == 2) {
            payment = new UpiPayment(id, order, date, late, policyFee, capped, reference);
        } else if (mode == 3) {
            payment = new CardPayment(id, order, date, late, policyFee, capped, reference);
        } else {
            payment = new CashPayment(id, order, date, late, policyFee, capped);
        }
        order.markPaid(payment);
        for (OrderItem item : order.getItems()) {
            item.getProduct().confirmSale(item.getQuantity());   // reserved units leave the stock
        }
        order.getCustomer().removeOpen(order);
        return payment;
    }

    // -------------------------------------------------------------- display
    public String customersTable() {
        StringBuilder sb = new StringBuilder();
        for (Customer c : customers.values()) {
            sb.append("  ").append(c).append('\n');
        }
        return sb.toString();
    }

    public String productsTable() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-5s %-22s %-16s %-9s %-7s %s%n", "ID", "Product", "Farmer", "Type",
                "Avail", "Price"));
        sb.append("-".repeat(84)).append('\n');
        if (products.isEmpty()) {
            sb.append("(no products added yet)\n");
        }
        for (Product p : products.values()) {
            sb.append(p).append('\n');
            if (p.isOrderable()) {
                sb.append(String.format("      %s | Village: %s | Max %d %s per order%n", p.getDescription(),
                        p.getFarmer().getVillage(), p.getMaxQtyPerOrder(), p.getUnit()));
            } else {
                sb.append(String.format("      %s | Village: %s | Out of season, display only%n",
                        p.getDescription(), p.getFarmer().getVillage()));
            }
        }
        return sb.toString();
    }

    public String openOrdersTable() {
        StringBuilder sb = new StringBuilder();
        for (Order o : orders.values()) {
            if (!o.isPaid()) {
                sb.append(String.format("  %-6s %-16s %-10s due %s  %s%n", o.getOrderId(),
                        DateUtil.fit(o.getCustomer().getName(), 16), DateUtil.money(o.getTotal()),
                        DateUtil.format(o.getDueDate()), o.itemList()));
            }
        }
        return sb.toString();
    }

    /** Units of orderable products that are on the shelf right now. */
    public int orderableAvailable() {
        int n = 0;
        for (Product p : products.values()) {
            if (p.isOrderable()) {
                n += p.getAvailableQty();
            }
        }
        return n;
    }

    public int orderableStock() {
        int n = 0;
        for (Product p : products.values()) {
            if (p.isOrderable()) {
                n += p.getStockQty();
            }
        }
        return n;
    }

    public boolean hasProducts() { return !products.isEmpty(); }

    public boolean hasCustomers() { return !customers.isEmpty(); }

    public boolean hasOpenOrders() { return !openOrdersTable().isEmpty(); }
}
