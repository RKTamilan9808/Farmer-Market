package exception;

/** Thrown when a product cannot be ordered (not enough stock, or out of season). */
public class OutOfStockException extends MarketException {
    private static final long serialVersionUID = 1L;

    public OutOfStockException(String message) { super(message); }
}
