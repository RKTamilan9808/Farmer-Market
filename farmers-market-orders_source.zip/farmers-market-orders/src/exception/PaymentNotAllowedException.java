package exception;

/** Thrown when a payment is not valid (order already paid). */
public class PaymentNotAllowedException extends MarketException {
    private static final long serialVersionUID = 1L;

    public PaymentNotAllowedException(String message) { super(message); }
}
