package exception;

/** Thrown when the user supplies malformed or out-of-range input. */
public class InvalidInputException extends MarketException {
    private static final long serialVersionUID = 1L;

    public InvalidInputException(String message) { super(message); }
}
