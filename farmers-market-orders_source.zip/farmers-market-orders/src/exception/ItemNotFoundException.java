package exception;

/** Thrown when a product, customer or order cannot be located. */
public class ItemNotFoundException extends MarketException {
    private static final long serialVersionUID = 1L;

    public ItemNotFoundException(String message) { super(message); }
}
