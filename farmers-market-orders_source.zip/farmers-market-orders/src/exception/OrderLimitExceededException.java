package exception;

/** Thrown when a customer asks for more open orders than the customer plan allows. */
public class OrderLimitExceededException extends MarketException {
    private static final long serialVersionUID = 1L;

    public OrderLimitExceededException(String message) { super(message); }
}
