package exception;

/** Thrown when a customer with an overdue unpaid order tries to order again. */
public class CustomerBlockedException extends MarketException {
    private static final long serialVersionUID = 1L;

    public CustomerBlockedException(String message) { super(message); }
}
