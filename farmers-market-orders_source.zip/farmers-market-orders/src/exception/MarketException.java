package exception;

/** Base class for all application-specific checked exceptions. */
public class MarketException extends Exception {
    private static final long serialVersionUID = 1L;

    public MarketException(String message) { super(message); }
}
