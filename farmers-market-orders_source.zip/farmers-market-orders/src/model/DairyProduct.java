package model;

/** A packaged dairy product (paneer, curd, ghee): sold per pack with a 5% packing charge. */
public class DairyProduct extends Product {
    public DairyProduct(String productId, String name, Farmer farmer, String description,
            double price, int stockQty) {
        super(productId, name, farmer, description, price, stockQty);
    }

    @Override
    public String getProductType() { return "Dairy"; }

    @Override
    public String getUnit() { return "pack"; }

    @Override
    public int getMaxQtyPerOrder() { return 10; }

    @Override
    public double getPackingRate() { return 0.05; }
}
