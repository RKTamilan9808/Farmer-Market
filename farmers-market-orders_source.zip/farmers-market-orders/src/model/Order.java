package model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import util.DateUtil;

/** A customer's purchase. It is composed of OrderItems (one per product). */
public final class Order implements Printable {
    private final String orderId;
    private final Customer customer;
    private final LocalDate orderDate;
    private final LocalDate dueDate;
    private final List<OrderItem> items = new ArrayList<>();
    private Payment payment;

    public Order(String orderId, Customer customer, Map<Product, Integer> lines, LocalDate orderDate) {
        this.orderId = orderId;
        this.customer = customer;
        this.orderDate = orderDate;
        this.dueDate = orderDate.plusDays(customer.getCreditDays());   // fixed at the time of ordering
        for (Map.Entry<Product, Integer> e : lines.entrySet()) {
            items.add(new OrderItem(this, e.getKey(), e.getValue(), customer.getDiscountRate()));
        }
    }

    public String getOrderId() { return orderId; }

    public Customer getCustomer() { return customer; }

    public LocalDate getOrderDate() { return orderDate; }

    public LocalDate getDueDate() { return dueDate; }

    public List<OrderItem> getItems() { return Collections.unmodifiableList(items); }

    public Payment getPayment() { return payment; }

    public boolean isPaid() { return payment != null; }

    public void markPaid(Payment payment) { this.payment = payment; }

    public boolean contains(Product product) {
        for (OrderItem i : items) {
            if (i.getProduct() == product) {
                return true;
            }
        }
        return false;
    }

    /** Number of days the payment is late if it is made on the given date (never negative). */
    public long daysLate(LocalDate on) { return Math.max(0, ChronoUnit.DAYS.between(dueDate, on)); }

    public double getSubtotal() {
        double t = 0;
        for (OrderItem i : items) {
            t += i.getLineAmount();
        }
        return DateUtil.round2(t);
    }

    public double getDiscount() {
        double t = 0;
        for (OrderItem i : items) {
            t += i.getDiscount();
        }
        return DateUtil.round2(t);
    }

    public double getPackingCharge() {
        double t = 0;
        for (OrderItem i : items) {
            t += i.getPackingCharge();
        }
        return DateUtil.round2(t);
    }

    /** Amount payable for the order (before any late fee). */
    public double getTotal() { return DateUtil.round2(getSubtotal() - getDiscount() + getPackingCharge()); }

    public String itemList() {
        StringBuilder sb = new StringBuilder();
        for (OrderItem i : items) {
            if (sb.length() > 0) {
                sb.append(", ");
            }
            sb.append(i.getProduct().getProductId()).append(" x").append(i.getQuantity());
        }
        return sb.toString();
    }

    @Override
    public String generateReceipt() {
        StringBuilder sb = new StringBuilder();
        sb.append("============== ORDER SLIP ==============\n");
        sb.append(String.format("Order ID    : %s%n", orderId));
        sb.append(String.format("Customer    : %s (%s, %s)%n", customer.getName(),
                customer.getCustomerId(), customer.getCustomerType()));
        sb.append(String.format("Ordered On  : %s%n", DateUtil.format(orderDate)));
        sb.append(String.format("Pay Before  : %s%n", DateUtil.format(dueDate)));
        sb.append("Items       :\n");
        for (OrderItem i : items) {
            Product p = i.getProduct();
            sb.append(String.format("  %-5s %-20s %3d %-4s x %-9s = %s%n", p.getProductId(),
                    DateUtil.fit(p.getName(), 20), i.getQuantity(), p.getUnit(),
                    DateUtil.money(i.getUnitPrice()), DateUtil.money(i.getLineAmount())));
        }
        sb.append(String.format("Sub total       : %s%n", DateUtil.money(getSubtotal())));
        if (getDiscount() > 0) {
            sb.append(String.format("Loyalty discount: -%s (%.0f%%)%n", DateUtil.money(getDiscount()),
                    customer.getDiscountRate() * 100));
        }
        if (getPackingCharge() > 0) {
            sb.append(String.format("Packing charge  : +%s%n", DateUtil.money(getPackingCharge())));
        }
        sb.append(String.format("Order total     : %s%n", DateUtil.money(getTotal())));
        sb.append(String.format("Open orders: %d of %d allowed%n", customer.getOpenCount(),
                customer.getMaxOpenOrders()));
        sb.append("--- Stock availability summary ---\n");
        for (OrderItem i : items) {
            Product p = i.getProduct();
            sb.append(String.format("  %-5s %-20s %d of %d %s available%n", p.getProductId(),
                    DateUtil.fit(p.getName(), 20), p.getAvailableQty(), p.getStockQty(), p.getUnit()));
        }
        sb.append("========================================");
        return sb.toString();
    }
}
