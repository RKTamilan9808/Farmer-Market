package model;

import java.time.LocalDate;
import util.DateUtil;

/**
 * Records the payment of one Order, the days it was late and the late fee payable.
 * The payment mode (cash / UPI / card) is provided by the subclasses (polymorphism).
 */
public abstract class Payment implements Printable {
    private final String paymentId;
    private final Order order;
    private final LocalDate paymentDate;
    private final long daysLate;
    private final boolean capped;
    private final double processingRate;
    private final double grossLateFee;
    private final double waiver;
    private final double lateFee;
    private final double processingFee;
    private final double totalPaid;

    protected Payment(String paymentId, Order order, LocalDate paymentDate, long daysLate,
            double policyLateFee, boolean capped, double processingRate) {
        this.paymentId = paymentId;
        this.order = order;
        this.paymentDate = paymentDate;
        this.daysLate = daysLate;
        this.capped = capped;
        this.processingRate = processingRate;
        this.grossLateFee = policyLateFee;
        double factor = order.getCustomer().getLateFeeFactor();
        this.lateFee = DateUtil.round2(policyLateFee * factor);
        this.waiver = DateUtil.round2(policyLateFee - lateFee);
        this.processingFee = DateUtil.round2((order.getTotal() + lateFee) * processingRate);
        this.totalPaid = DateUtil.round2(order.getTotal() + lateFee + processingFee);
    }

    // ---- polymorphic payment-mode rules ----
    public abstract String getMode();

    /** Gateway / processing fee as a fraction of the amount (0.015 = 1.5%). */
    public double getProcessingRate() { return processingRate; }

    /** How the payment was made, e.g. "UPI (name@bank)". */
    public abstract String describe();

    public String getPaymentId() { return paymentId; }

    public Order getOrder() { return order; }

    public long getDaysLate() { return daysLate; }

    public double getLateFee() { return lateFee; }

    public double getTotalPaid() { return totalPaid; }

    @Override
    public String generateReceipt() {
        Customer c = order.getCustomer();
        StringBuilder sb = new StringBuilder();
        sb.append("=============== PAYMENT RECEIPT ===============\n");
        sb.append(String.format("Receipt ID       : %s%n", paymentId));
        sb.append(String.format("Order ID         : %s%n", order.getOrderId()));
        sb.append(String.format("Customer         : %s (%s, %s)%n", c.getName(), c.getCustomerId(),
                c.getCustomerType()));
        sb.append(String.format("Items            : %s%n", order.itemList()));
        sb.append(String.format("Ordered On       : %s%n", DateUtil.format(order.getOrderDate())));
        sb.append(String.format("Pay Before       : %s%n", DateUtil.format(order.getDueDate())));
        if (daysLate > 0) {
            sb.append(String.format("Paid On          : %s (%d day(s) late)%n", DateUtil.format(paymentDate), daysLate));
        } else {
            sb.append(String.format("Paid On          : %s (on time)%n", DateUtil.format(paymentDate)));
        }
        sb.append(String.format("Pay Mode         : %s%n", describe()));
        sb.append(String.format("Order total      : %s%n", DateUtil.money(order.getTotal())));
        sb.append(String.format("Late fee (policy): %s%s%n", DateUtil.money(grossLateFee),
                capped ? " (capped at 20% of order)" : ""));
        if (waiver > 0) {
            sb.append(String.format("Member waiver    : -%s (%.0f%%)%n", DateUtil.money(waiver),
                    (1 - c.getLateFeeFactor()) * 100));
        }
        if (processingFee > 0) {
            sb.append(String.format("Processing fee   : +%s (%.1f%%)%n", DateUtil.money(processingFee),
                    getProcessingRate() * 100));
        }
        sb.append(String.format("Amount Paid      : %s%n", DateUtil.money(totalPaid)));
        sb.append("===============================================");
        return sb.toString();
    }
}
