package model;

import exception.OutOfStockException;
import util.DateUtil;

/**
 * A product sold by a farmer. Unit, order limit, packing charge and ordering permission
 * are exposed through overridable methods so that DairyProduct, OrganicProduct and
 * SeasonalProduct can change them (polymorphism).
 */
public class Product {
    private final String productId;
    private final String name;
    private final Farmer farmer;
    private final String description;
    private final double price;          // price per unit
    private int stockQty;                // units held by the farmer (includes reserved units)
    private int reservedQty;             // units reserved by unpaid orders

    public Product(String productId, String name, Farmer farmer, String description,
            double price, int stockQty) {
        this.productId = productId;
        this.name = name;
        this.farmer = farmer;
        this.description = description;
        this.price = price;
        this.stockQty = stockQty;
        this.reservedQty = 0;
    }

    // ---- polymorphic business rules ----
    public String getProductType() { return "Produce"; }

    public String getUnit() { return "kg"; }

    public int getMaxQtyPerOrder() { return 20; }

    /** Packing charge rate applied on the line amount (0.05 = 5%). */
    public double getPackingRate() { return 0.0; }

    /** True if the loyalty discount of a customer applies to this product. */
    public boolean isDiscountable() { return true; }

    public boolean isOrderable() { return true; }

    // ---- stock (all changes go through these methods) ----
    public int getAvailableQty() { return isOrderable() ? stockQty - reservedQty : 0; }

    /** Reserves units for a newly placed order. */
    public void reserve(int qty) throws OutOfStockException {
        if (!isOrderable()) {
            throw new OutOfStockException("'" + name + "' is out of season (display only).");
        }
        if (qty > getAvailableQty()) {
            throw new OutOfStockException("Only " + getAvailableQty() + " " + getUnit() + " of '" + name
                    + "' (" + productId + ") available; " + qty + " requested.");
        }
        reservedQty += qty;
    }

    /** Confirms the sale when the order is paid: the units leave the stock. */
    public void confirmSale(int qty) {
        reservedQty = Math.max(0, reservedQty - qty);
        stockQty = Math.max(0, stockQty - qty);
    }

    // ---- getters ----
    public String getProductId() { return productId; }

    public String getName() { return name; }

    public Farmer getFarmer() { return farmer; }

    public String getDescription() { return description; }

    public double getPrice() { return price; }

    public int getStockQty() { return stockQty; }

    @Override
    public String toString() {
        return String.format("%-5s %-22s %-16s %-9s %3d/%-3d %s",
                productId, DateUtil.fit(name, 22), DateUtil.fit(farmer.getName(), 16),
                getProductType(), getAvailableQty(), stockQty,
                DateUtil.money(price) + "/" + getUnit());
    }
}
