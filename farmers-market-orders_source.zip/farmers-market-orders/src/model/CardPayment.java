package model;

import java.time.LocalDate;

/** Payment by debit/credit card: a 1.5% processing fee is added; only the last 4 digits are kept. */
public class CardPayment extends Payment {
    private final String last4;

    public CardPayment(String paymentId, Order order, LocalDate date, long daysLate,
            double policyLateFee, boolean capped, String last4) {
        super(paymentId, order, date, daysLate, policyLateFee, capped, 0.015);
        this.last4 = last4;
    }

    @Override
    public String getMode() { return "Card"; }

    @Override
    public String describe() { return "Card (**** " + last4 + ")"; }
}
