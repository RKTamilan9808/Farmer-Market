package model;

/** The farmer who grows one or more products. A Product refers to a shared Farmer object (aggregation). */
public class Farmer {
    private final String farmerId;
    private final String name;
    private final String village;

    public Farmer(String farmerId, String name, String village) {
        this.farmerId = farmerId;
        this.name = name;
        this.village = village;
    }

    public String getFarmerId() { return farmerId; }

    public String getName() { return name; }

    public String getVillage() { return village; }

    @Override
    public String toString() { return name + ", " + village; }
}
