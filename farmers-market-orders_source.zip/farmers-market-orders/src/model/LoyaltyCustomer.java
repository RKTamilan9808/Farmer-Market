package model;

/** Loyalty customer: 5 open orders, 7 days to pay, 5% discount and half the late fee. */
public class LoyaltyCustomer extends Customer {
    public LoyaltyCustomer(String customerId, String name, String phone) { super(customerId, name, phone); }

    @Override
    public int getMaxOpenOrders() { return 5; }

    @Override
    public int getCreditDays() { return 7; }

    @Override
    public double getDiscountRate() { return 0.05; }

    @Override
    public double getLateFeeFactor() { return 0.5; }

    @Override
    public String getCustomerType() { return "Loyalty"; }
}
