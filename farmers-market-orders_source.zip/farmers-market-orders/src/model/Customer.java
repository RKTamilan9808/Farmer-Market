package model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import util.DateUtil;

/**
 * A regular customer. Open-order limit, credit period, discount and late-fee terms are exposed
 * through overridable methods so that LoyaltyCustomer can change them (polymorphism).
 */
public class Customer {
    private final String customerId;
    private String name;
    private String phone;
    private final List<Order> openOrders = new ArrayList<>();   // unpaid orders (aggregation)

    public Customer(String customerId, String name, String phone) {
        this.customerId = customerId;
        this.name = name;
        this.phone = phone;
    }

    // ---- polymorphic business rules ----
    public int getMaxOpenOrders() { return 3; }

    /** Days allowed to pay after the order date. */
    public int getCreditDays() { return 2; }

    /** Discount rate on discountable items (0.05 = 5%). */
    public double getDiscountRate() { return 0.0; }

    /** Multiplier applied to the late fee (1.0 = full late fee). */
    public double getLateFeeFactor() { return 1.0; }

    public String getCustomerType() { return "Regular"; }

    // ---- unpaid orders ----
    public void addOpen(Order order) { openOrders.add(order); }

    public void removeOpen(Order order) { openOrders.remove(order); }

    public List<Order> getOpenOrders() { return Collections.unmodifiableList(openOrders); }

    public int getOpenCount() { return openOrders.size(); }

    /** True if the customer already has the same product in an unpaid order. */
    public boolean holds(Product product) {
        for (Order o : openOrders) {
            if (o.contains(product)) {
                return true;
            }
        }
        return false;
    }

    /** True if any unpaid order is past its due date on the given day. */
    public boolean hasOverdue(LocalDate on) {
        for (Order o : openOrders) {
            if (on.isAfter(o.getDueDate())) {
                return true;
            }
        }
        return false;
    }

    // ---- getters / setters ----
    public String getCustomerId() { return customerId; }

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    public String getPhone() { return phone; }

    public void setPhone(String phone) { this.phone = phone; }

    @Override
    public String toString() {
        return String.format("%-5s %-20s %-8s max %d open orders | open: %d",
                customerId, DateUtil.fit(name, 20), getCustomerType(), getMaxOpenOrders(), getOpenCount());
    }
}
