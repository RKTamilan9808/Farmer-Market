package model;

/** An out-of-season product (e.g. mangoes in winter): shown in the catalogue but never ordered. */
public class SeasonalProduct extends Product {
    public SeasonalProduct(String productId, String name, Farmer farmer, String description,
            double price, int stockQty) {
        super(productId, name, farmer, description, price, stockQty);
    }

    @Override
    public String getProductType() { return "Seasonal"; }

    @Override
    public int getMaxQtyPerOrder() { return 0; }

    @Override
    public boolean isOrderable() { return false; }
}
