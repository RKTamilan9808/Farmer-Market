package model;

import util.DateUtil;

/** One product line inside an order. It links directly to its Order and to the Product (business rule 5). */
public class OrderItem {
    private final Order order;
    private final Product product;
    private final int quantity;
    private final double unitPrice;     // price is fixed at the time of ordering
    private final double lineAmount;
    private final double discount;
    private final double packingCharge;

    public OrderItem(Order order, Product product, int quantity, double discountRate) {
        this.order = order;
        this.product = product;
        this.quantity = quantity;
        this.unitPrice = product.getPrice();
        this.lineAmount = DateUtil.round2(quantity * unitPrice);
        this.discount = product.isDiscountable() ? DateUtil.round2(lineAmount * discountRate) : 0.0;
        this.packingCharge = DateUtil.round2((lineAmount - discount) * product.getPackingRate());
    }

    public Order getOrder() { return order; }

    public Product getProduct() { return product; }

    public int getQuantity() { return quantity; }

    public double getUnitPrice() { return unitPrice; }

    public double getLineAmount() { return lineAmount; }

    public double getDiscount() { return discount; }

    public double getPackingCharge() { return packingCharge; }

    /** Amount payable for this line: amount - discount + packing charge. */
    public double getNetAmount() { return DateUtil.round2(lineAmount - discount + packingCharge); }
}
