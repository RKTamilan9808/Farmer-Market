package model;

/** Anything that can print its own receipt (implemented by Order and Payment). */
public interface Printable {
    String generateReceipt();
}
