package model;

import java.time.LocalDate;

/** Payment through UPI: no processing fee, the UPI ID is recorded on the receipt. */
public class UpiPayment extends Payment {
    private final String upiId;

    public UpiPayment(String paymentId, Order order, LocalDate date, long daysLate,
            double policyLateFee, boolean capped, String upiId) {
        super(paymentId, order, date, daysLate, policyLateFee, capped, 0.0);
        this.upiId = upiId;
    }

    @Override
    public String getMode() { return "UPI"; }

    @Override
    public String describe() { return "UPI (" + upiId + ")"; }
}
