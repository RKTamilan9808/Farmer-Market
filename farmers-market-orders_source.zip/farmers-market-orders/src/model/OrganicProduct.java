package model;

/** A certified organic product: small order limit and no loyalty discount (already premium priced). */
public class OrganicProduct extends Product {
    public OrganicProduct(String productId, String name, Farmer farmer, String description,
            double price, int stockQty) {
        super(productId, name, farmer, description, price, stockQty);
    }

    @Override
    public String getProductType() { return "Organic"; }

    @Override
    public int getMaxQtyPerOrder() { return 10; }

    @Override
    public boolean isDiscountable() { return false; }
}
