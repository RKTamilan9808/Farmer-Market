package model;

import java.time.LocalDate;

/** Payment in cash at the market counter: no processing fee. */
public class CashPayment extends Payment {
    public CashPayment(String paymentId, Order order, LocalDate date, long daysLate,
            double policyLateFee, boolean capped) {
        super(paymentId, order, date, daysLate, policyLateFee, capped, 0.0);
    }

    @Override
    public String getMode() { return "Cash"; }

    @Override
    public String describe() { return "Cash"; }
}
