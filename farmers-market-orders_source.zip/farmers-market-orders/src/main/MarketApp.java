package main;

import exception.InvalidInputException;
import exception.MarketException;
import java.time.LocalDate;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Scanner;
import model.Customer;
import model.Order;
import model.Payment;
import model.Product;
import service.MarketService;
import util.DateUtil;
import util.InputHelper;

/** Entry point: menu-driven console interface for the Farmers' Market Orders & Payments system. */
public class MarketApp {

    private static void printMenu() {
        System.out.println();
        System.out.println("*********** FARMERS' MARKET ORDERS & PAYMENTS ***********");
        System.out.println(" 1. Add Product");
        System.out.println(" 2. Register Customer");
        System.out.println(" 3. Place Order");
        System.out.println(" 4. Make Payment");
        System.out.println(" 5. Display Products & Stock");
        System.out.println(" 6. Exit");
        System.out.println("*********************************************************");
    }

    public static void main(String[] args) {
        MarketService service = new MarketService("Green Valley Farmers' Market");
        Scanner scanner = new Scanner(System.in);
        InputHelper in = new InputHelper(scanner);
        System.out.println("Welcome to " + service.getName());
        boolean running = true;
        while (running) {
            printMenu();
            try {
                int choice = in.readInt("Enter your choice (1-6): ", 1, 6);
                switch (choice) {
                    case 1: addProduct(service, in); break;
                    case 2: registerCustomer(service, in); break;
                    case 3: placeOrder(service, in); break;
                    case 4: makePayment(service, in); break;
                    case 5: displayProducts(service); break;
                    case 6:
                        System.out.println("Thank you for using the Farmers' Market system. Goodbye!");
                        running = false;
                        break;
                    default: break;
                }
            } catch (MarketException e) {
                System.out.println("[ERROR] " + e.getMessage());
            } catch (NoSuchElementException e) {
                System.out.println("\nInput ended. Exiting.");
                running = false;
            } catch (RuntimeException e) {
                System.out.println("[UNEXPECTED ERROR] " + e.getMessage());
            }
        }
        scanner.close();
    }

    private static void addProduct(MarketService svc, InputHelper in) throws MarketException {
        System.out.println("--- Add Product ---");
        String name = in.readText("Product name   : ");
        String farmer = in.readName("Farmer name    : ");
        String village = in.readName("Village        : ");
        String description = in.readText("Description    : ");
        int type = in.readInt("Type (1=Produce, 2=Dairy, 3=Organic, 4=Seasonal): ", 1, 4);
        int qty = in.readInt("Quantity in stock (1-500): ", 1, 500);
        double price = in.readPrice("Price per unit (Rs.) : ", 1, 10000);
        Product p = svc.addProduct(name, farmer, village, description, type, qty, price);
        System.out.println("[OK] Product added -> " + p.getProductId() + " | " + p.getName() + " | "
                + p.getProductType() + " | " + p.getStockQty() + " " + p.getUnit() + " | "
                + DateUtil.money(p.getPrice()) + "/" + p.getUnit());
    }

    private static void registerCustomer(MarketService svc, InputHelper in) throws MarketException {
        System.out.println("--- Register Customer ---");
        String name = in.readName("Customer name  : ");
        String phone = in.readPhone("Mobile number  : ");
        int type = in.readInt("Type (1=Regular, 2=Loyalty): ", 1, 2);
        Customer c = svc.registerCustomer(name, phone, type == 2);
        System.out.println("[OK] Customer registered -> " + c.getCustomerId() + " | " + c.getName() + " | "
                + c.getCustomerType() + " | max " + c.getMaxOpenOrders() + " open orders");
    }

    private static void placeOrder(MarketService svc, InputHelper in) throws MarketException {
        System.out.println("--- Place Order ---");
        if (!svc.hasProducts() || !svc.hasCustomers()) {
            System.out.println("[INFO] Add a product and register a customer first.");
            return;
        }
        System.out.println("Registered customers:");
        System.out.print(svc.customersTable());
        String cid = in.readText("Customer ID : ");
        Customer customer = svc.findCustomer(cid);          // fail fast on a bad ID
        System.out.print(svc.productsTable());
        Map<String, Integer> lines = in.readOrderLines("Order items (e.g. P001:3,P002:2): ");
        LocalDate date = in.readDate("Order date (dd-MM-yyyy, Enter = today): ", true);
        Order order = svc.placeOrder(customer.getCustomerId(), lines, date);
        System.out.println(order.generateReceipt());
        System.out.println("Updated stock -> " + svc.orderableAvailable() + " of "
                + svc.orderableStock() + " orderable units available");
    }

    private static void makePayment(MarketService svc, InputHelper in) throws MarketException {
        System.out.println("--- Make Payment ---");
        if (!svc.hasOpenOrders()) {
            System.out.println("[INFO] There are no unpaid orders.");
            return;
        }
        System.out.println("Unpaid orders:");
        System.out.print(svc.openOrdersTable());
        String oid = in.readText("Order ID : ");
        Order order = svc.findOrder(oid);                   // fail fast on a bad ID
        if (order.isPaid()) {
            throw new InvalidInputException("Order " + order.getOrderId() + " is already paid.");
        }
        int mode = in.readInt("Payment mode (1=Cash, 2=UPI, 3=Card): ", 1, 3);
        String reference = null;
        if (mode == 2) {
            reference = in.readUpiId("UPI ID : ");
        } else if (mode == 3) {
            reference = in.readCardLast4("Card last 4 digits : ");
        }
        LocalDate date = in.readDate("Payment date (dd-MM-yyyy, Enter = today): ", true);
        Payment payment = svc.makePayment(order.getOrderId(), mode, reference, date);
        System.out.println(payment.generateReceipt());
        System.out.println("Updated stock -> " + svc.orderableAvailable() + " of "
                + svc.orderableStock() + " orderable units available");
    }

    private static void displayProducts(MarketService svc) {
        System.out.println("--- Products & Stock ---");
        System.out.print(svc.productsTable());
        if (svc.hasProducts()) {
            System.out.println("Market total : " + svc.orderableAvailable() + " of " + svc.orderableStock()
                    + " orderable units available");
        }
    }
}
